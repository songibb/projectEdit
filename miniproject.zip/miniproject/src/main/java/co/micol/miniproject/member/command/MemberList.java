package co.micol.miniproject.member.command;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.micol.miniproject.common.Command;
import co.micol.miniproject.member.service.MemberService;
import co.micol.miniproject.member.serviceImpl.MemberServiceImpl;

public class MemberList implements Command {

	@Override
	public String run(HttpServletRequest request, HttpServletResponse response) {
		// 멤버목록
		MemberService ms = new MemberServiceImpl();
		List<Object> members = new ArrayList<Object>();
		members = ms.memberSelectList();
		
		request.setAttribute("members", members);
		
		return "member/memberList";
	}

}
