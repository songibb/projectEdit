package co.market.lemon.mypage.service;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HeartVO {
	//찜목록
	private String memberId;
	private int productId;
}
