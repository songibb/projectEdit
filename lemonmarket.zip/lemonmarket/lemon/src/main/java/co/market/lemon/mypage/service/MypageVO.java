package co.market.lemon.mypage.service;

public class MypageVO {

}
